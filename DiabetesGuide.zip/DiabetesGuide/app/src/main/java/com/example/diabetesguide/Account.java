package com.example.diabetesguide;

public class Account {
}
