package com.example.diabetesguide;

public class Home {
}
